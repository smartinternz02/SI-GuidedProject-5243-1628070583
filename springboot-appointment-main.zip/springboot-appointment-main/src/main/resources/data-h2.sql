INSERT INTO Doctor (name,specialization,degree,state,city) VALUES
('Dr. Agarwal Priyank','Orthopaedic Surgeon','MBBS, MS (Ortho)','Madhya Pradesh','Sagar'),
('Dr. Achwal Suvarna','Gynaecologist','MBBS, DGO','Madhya Pradesh','Sagar'),
('Dr. Aggarwal Supriya','ENT Surgeon','MBBS, DLO','Madhya Pradesh','Rewa'),
('Dr. Baghel Yadvendra Singh','ENT Surgeon','MBBS, DLO','Madhya Pradesh','Rewa');