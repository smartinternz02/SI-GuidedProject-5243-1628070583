package com.externship.appointment.Appointment_storage;

public class AppointmentDelete {
	private String appId;

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}
}
