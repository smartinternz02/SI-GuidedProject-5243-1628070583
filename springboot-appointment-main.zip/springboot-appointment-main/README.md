# springboot-appointment
A repo for a doctor's appointment management webapp using springboot.
